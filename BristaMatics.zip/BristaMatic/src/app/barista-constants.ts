export class IngredientItem {
  name?: string;
  price?: number;
}

export class Ingredient {
  coffee?: number;
  decafCoffee?: number;
  sugar?: number;
  cream?: number;
  steamedMilk?: number;
  espresso?: number;
  foamedMilk?: number;
  cocoa?: number;
  whippedCream?: number;
}

export class MenuItem {
  name?: string;
  price?: number;
}

export class composition {
  name?: string;
  ingredient?: Ingredient;
}

export class InventoryItem {
  name?: string;
  quantity?: number;
}

export const IngredientItems: IngredientItem[] = [
  {
    name: 'coffee',
    price: 0.75,
  },
  {
    name: 'decafCoffee',
    price: 0.75,
  },
  {
    name: 'sugar',
    price: 0.25,
  },
  {
    name: 'cream',
    price: 0.25,
  },
  {
    name: 'steamedMilk',
    price: 0.35,
  },
  {
    name: 'foamedMilk',
    price: 0.35,
  },
  {
    name: 'espresso',
    price: 1.1,
  },
  {
    name: 'cocoa',
    price: 0.9,
  },
  {
    name: 'whippedCream',
    price: 1.0,
  },
];

export const Drinks: composition[] = [
  {
    name: 'Coffee',
    ingredient: {
      coffee: 3,
      sugar: 1,
      cream: 1,
    },
  },
  {
    name: 'Decaf Coffee',
    ingredient: {
      decafCoffee: 3,
      sugar: 1,
      cream: 1,
    },
  },
  {
    name: 'Caffe Latte',
    ingredient: {
      espresso: 2,
      steamedMilk: 1,
    },
  },
  {
    name: 'Caffe Americano',
    ingredient: {
      espresso: 3,
    },
  },
  {
    name: 'Caffe Mocha',
    ingredient: {
      espresso: 1,
      cocoa: 1,
      steamedMilk: 1,
      whippedCream: 1,
    },
  },
  {
    name: 'Cappuccino',
    ingredient: {
      espresso: 2,
      steamedMilk: 1,
      foamedMilk: 1,
    },
  },
];

export const InventoryItems: InventoryItem[] = [
  {
    name: 'coffee',
    quantity: 10,
  },
  {
    name: 'decafCoffee',
    quantity: 10,
  },
  {
    name: 'sugar',
    quantity: 10,
  },
  {
    name: 'cream',
    quantity: 10,
  },
  {
    name: 'steamedMilk',
    quantity: 10,
  },
  {
    name: 'foamedMilk',
    quantity: 10,
  },
  {
    name: 'espresso',
    quantity: 10,
  },
  {
    name: 'cocoa',
    quantity: 10,
  },
  {
    name: 'whippedCream',
    quantity: 10,
  },
];
