import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CoffeeMakerService } from '../coffee-maker.service';
import {
  composition,
  Drinks,
  Ingredient,
  IngredientItems,
  InventoryItems,
  MenuItem,
} from '../barista-constants';

@Component({
  selector: 'app-order-online',
  templateUrl: './order-online.component.html',
  styleUrls: ['./order-online.component.scss'],
})
export class OrderOnlineComponent implements OnInit {
  InventoryColumns: string[] = ['name', 'quantity'];
  DrinksColumns: string[] = ['name', 'price', 'actionsColumn'];
  cartColumns: string[] = ['name', 'price', 'actionsColumn'];
  cartItems: MenuItem[] = [
    {
      name: 'add item',
      price: 0,
    },
  ];
  drinks = Drinks;
  inventoryItems = [...InventoryItems];
  constructor(
    public coffeeMakerService: CoffeeMakerService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {}

  addToCart(item: composition) {
    let cartItems = this.cartItems;
    if (cartItems[0].name === 'add item') {
      cartItems = [];
    }
    if (this.checkInventory(item.ingredient)) {
      cartItems.push({
        name: item.name,
        price: this.coffeeMakerService.getPrice(item.ingredient),
      });
      this.cartItems = [...cartItems];
    } else {
      alert('Out of ingredients! Please try other items');
    }
    this.cdr.detectChanges();
  }

  deleteItem(itemIndex: number) {
    let items = this.cartItems;
    if (items[0].name !== 'add item') {
      if (this.updateInventory(items[itemIndex].name)) {
        items.splice(itemIndex, 1);
      }
    } else {
      alert('Please add items....');
    }
    if (items.length === 0) {
      items.push({
        name: 'add item',
        price: 0,
      });
    }
    this.cartItems = [...items];
    this.cdr.detectChanges();
  }

  getTotalCost() {
    let price = 0;
    this.cartItems.forEach((item) => {
      price = item.price ? price + item.price : price;
    });
    return price;
  }

  checkInventory(addedDrink?: any) {
    let status = false;
    let inventoryItem = this.coffeeMakerService.inventoryItems;
    if (addedDrink) {
      status = inventoryItem.some((item: any) => {
        let updatedValue = 0;
        if (item && addedDrink && addedDrink[item.name]) {
          updatedValue = item.quantity - addedDrink[item.name];
          item.quantity = updatedValue < 0 ? item.quantity : updatedValue;
        }
        return updatedValue < 0;
      });
      this.coffeeMakerService.inventoryItems = status
        ? this.coffeeMakerService.inventoryItems
        : inventoryItem;
    }
    return !status;
  }

  updateInventory(deletedDrink: any) {
    let status = false;
    let inventoryItem = this.coffeeMakerService.inventoryItems;
    let deletedDrinkItem: any = Drinks.find((drink) => {
      return drink.name === deletedDrink;
    });
    console.log(deletedDrinkItem);
    if (deletedDrink) {
      status = inventoryItem.some((item: any) => {
        let updatedValue = 0;
        if (
          item &&
          deletedDrinkItem &&
          deletedDrinkItem.ingredient[item.name]
        ) {
          updatedValue = item.quantity + deletedDrinkItem.ingredient[item.name];
          item.quantity = updatedValue > 10 ? item.quantity : updatedValue;
        }
        return updatedValue > 10;
      });
      this.coffeeMakerService.inventoryItems = status
        ? this.coffeeMakerService.inventoryItems
        : inventoryItem;
    }
    return !status;
  }

  resetAll() {
    this.inventoryItems.forEach((ingredient) => {
      ingredient.quantity = 10;
    });
    this.cartItems = [
      {
        name: 'add item',
        price: 0,
      },
    ];
    this.cdr.detectChanges();
  }
}
