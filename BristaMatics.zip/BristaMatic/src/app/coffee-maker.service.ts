import { Injectable } from '@angular/core';
import {
  Drinks,
  IngredientItems,
  InventoryItems,
  MenuItem,
} from './barista-constants';

@Injectable({
  providedIn: 'root',
})
export class CoffeeMakerService {
  menuItemsWithCost: MenuItem[] = [];
  inventoryItems = [...InventoryItems];
  cartItems: any[] = [];

  constructor() {
    Drinks.forEach((ele) => {
      this.menuItemsWithCost.push({
        name: ele.name,
        price: this.getPrice(ele.ingredient),
      });
    });
  }

  public getPrice(inventoryItem: any): number {
    let price = 0;
    IngredientItems.forEach((ele: any) => {
      if (inventoryItem[ele.name]) {
        price = price + ele?.price * inventoryItem[ele.name];
      }
    });
    return Math.round(price * 100) / 100;
  }
}
