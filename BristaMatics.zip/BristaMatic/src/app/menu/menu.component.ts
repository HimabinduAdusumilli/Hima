import { Component, OnInit, Input } from '@angular/core';
import { CoffeeMakerService } from '../coffee-maker.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.scss'],
})
export class MenuComponent implements OnInit {
  @Input()
  orderOnline: boolean = false;

  drinksMenuColumns: string[] = ['name', 'price'];

  constructor(public coffeeMakerService: CoffeeMakerService) {}

  ngOnInit(): void {}
}
